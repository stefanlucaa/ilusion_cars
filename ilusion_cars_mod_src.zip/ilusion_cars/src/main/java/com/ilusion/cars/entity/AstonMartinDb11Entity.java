package com.ilusion.cars.entity;

import com.ilusion.cars.init.EntityInit;
import net.minecraft.entity.EntityType;
import net.minecraft.world.World;

/** Aston Martin DB11 */
public class AstonMartinDb11Entity extends BaseCarEntity {

    public AstonMartinDb11Entity(EntityType<? extends BaseCarEntity> type, World world) {
        super(type, world);
        this.maxSpeed  = 1.05f;
        this.accel     = 0.07f;
        this.turnSpeed = 5.2f;
        this.hasSiren  = false;
    }
}
