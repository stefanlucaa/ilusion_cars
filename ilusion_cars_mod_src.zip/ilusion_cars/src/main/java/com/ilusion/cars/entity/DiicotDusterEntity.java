package com.ilusion.cars.entity;

import com.ilusion.cars.init.EntityInit;
import net.minecraft.entity.EntityType;
import net.minecraft.world.World;

/** DIICOT Duster */
public class DiicotDusterEntity extends BaseCarEntity {

    public DiicotDusterEntity(EntityType<? extends BaseCarEntity> type, World world) {
        super(type, world);
        this.maxSpeed  = 0.65f;
        this.accel     = 0.042f;
        this.turnSpeed = 4.0f;
        this.hasSiren  = true;
    }
}
