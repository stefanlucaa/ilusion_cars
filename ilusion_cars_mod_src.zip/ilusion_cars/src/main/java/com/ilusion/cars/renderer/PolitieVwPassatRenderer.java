package com.ilusion.cars.renderer;

import com.ilusion.cars.entity.PolitieVwPassatEntity;
import com.ilusion.cars.model.PolitieVwPassatModel;
import net.minecraft.client.renderer.entity.EntityRendererManager;

public class PolitieVwPassatRenderer extends BaseCarRenderer<PolitieVwPassatEntity> {
    public PolitieVwPassatRenderer(EntityRendererManager manager) {
        super(manager, new PolitieVwPassatModel(), "politie_vw_passat");
    }
}
