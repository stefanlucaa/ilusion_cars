package com.ilusion.cars.model;

import com.ilusion.cars.entity.DodgeChallengerRtEntity;

public class DodgeChallengerRtModel extends BaseCarModel<DodgeChallengerRtEntity> {

    @Override
    protected void buildParts() {
        setupParts(
            24,   // body half-length
            12,   // body half-width
            3,   // body bottom y
            6,   // body top y
            10,   // cabin top y
            true,
            false
        );
    }
}
