package com.ilusion.cars.renderer;

import com.ilusion.cars.entity.MercedesMaybachSEntity;
import com.ilusion.cars.model.MercedesMaybachSModel;
import net.minecraft.client.renderer.entity.EntityRendererManager;

public class MercedesMaybachSRenderer extends BaseCarRenderer<MercedesMaybachSEntity> {
    public MercedesMaybachSRenderer(EntityRendererManager manager) {
        super(manager, new MercedesMaybachSModel(), "mercedes_maybach_s");
    }
}
