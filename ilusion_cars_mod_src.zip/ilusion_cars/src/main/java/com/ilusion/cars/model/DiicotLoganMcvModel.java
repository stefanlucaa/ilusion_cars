package com.ilusion.cars.model;

import com.ilusion.cars.entity.DiicotLoganMcvEntity;

public class DiicotLoganMcvModel extends BaseCarModel<DiicotLoganMcvEntity> {

    @Override
    protected void buildParts() {
        setupParts(
            24,   // body half-length
            11,   // body half-width
            3,   // body bottom y
            7,   // body top y
            11,   // cabin top y
            false,
            true
        );
    }
}
