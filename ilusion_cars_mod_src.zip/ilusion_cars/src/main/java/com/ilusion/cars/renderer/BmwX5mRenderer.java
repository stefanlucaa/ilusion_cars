package com.ilusion.cars.renderer;

import com.ilusion.cars.entity.BmwX5mEntity;
import com.ilusion.cars.model.BmwX5mModel;
import net.minecraft.client.renderer.entity.EntityRendererManager;

public class BmwX5mRenderer extends BaseCarRenderer<BmwX5mEntity> {
    public BmwX5mRenderer(EntityRendererManager manager) {
        super(manager, new BmwX5mModel(), "bmw_x5m");
    }
}
