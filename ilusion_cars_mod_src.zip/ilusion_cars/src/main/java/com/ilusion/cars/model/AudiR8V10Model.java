package com.ilusion.cars.model;

import com.ilusion.cars.entity.AudiR8V10Entity;

public class AudiR8V10Model extends BaseCarModel<AudiR8V10Entity> {

    @Override
    protected void buildParts() {
        setupParts(
            25,   // body half-length
            11,   // body half-width
            2,   // body bottom y
            5,   // body top y
            9,   // cabin top y
            true,
            false
        );
    }
}
