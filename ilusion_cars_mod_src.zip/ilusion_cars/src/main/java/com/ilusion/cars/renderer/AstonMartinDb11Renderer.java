package com.ilusion.cars.renderer;

import com.ilusion.cars.entity.AstonMartinDb11Entity;
import com.ilusion.cars.model.AstonMartinDb11Model;
import net.minecraft.client.renderer.entity.EntityRendererManager;

public class AstonMartinDb11Renderer extends BaseCarRenderer<AstonMartinDb11Entity> {
    public AstonMartinDb11Renderer(EntityRendererManager manager) {
        super(manager, new AstonMartinDb11Model(), "aston_martin_db11");
    }
}
