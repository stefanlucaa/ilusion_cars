package com.ilusion.cars.renderer;

import com.ilusion.cars.entity.DiicotDusterEntity;
import com.ilusion.cars.model.DiicotDusterModel;
import net.minecraft.client.renderer.entity.EntityRendererManager;

public class DiicotDusterRenderer extends BaseCarRenderer<DiicotDusterEntity> {
    public DiicotDusterRenderer(EntityRendererManager manager) {
        super(manager, new DiicotDusterModel(), "diicot_duster");
    }
}
