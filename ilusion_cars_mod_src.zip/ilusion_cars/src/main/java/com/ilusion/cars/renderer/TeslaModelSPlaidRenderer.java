package com.ilusion.cars.renderer;

import com.ilusion.cars.entity.TeslaModelSPlaidEntity;
import com.ilusion.cars.model.TeslaModelSPlaidModel;
import net.minecraft.client.renderer.entity.EntityRendererManager;

public class TeslaModelSPlaidRenderer extends BaseCarRenderer<TeslaModelSPlaidEntity> {
    public TeslaModelSPlaidRenderer(EntityRendererManager manager) {
        super(manager, new TeslaModelSPlaidModel(), "tesla_model_s_plaid");
    }
}
