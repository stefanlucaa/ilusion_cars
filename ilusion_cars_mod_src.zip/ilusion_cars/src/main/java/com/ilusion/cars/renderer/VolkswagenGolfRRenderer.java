package com.ilusion.cars.renderer;

import com.ilusion.cars.entity.VolkswagenGolfREntity;
import com.ilusion.cars.model.VolkswagenGolfRModel;
import net.minecraft.client.renderer.entity.EntityRendererManager;

public class VolkswagenGolfRRenderer extends BaseCarRenderer<VolkswagenGolfREntity> {
    public VolkswagenGolfRRenderer(EntityRendererManager manager) {
        super(manager, new VolkswagenGolfRModel(), "volkswagen_golf_r");
    }
}
