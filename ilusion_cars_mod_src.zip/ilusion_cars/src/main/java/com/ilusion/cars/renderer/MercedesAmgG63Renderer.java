package com.ilusion.cars.renderer;

import com.ilusion.cars.entity.MercedesAmgG63Entity;
import com.ilusion.cars.model.MercedesAmgG63Model;
import net.minecraft.client.renderer.entity.EntityRendererManager;

public class MercedesAmgG63Renderer extends BaseCarRenderer<MercedesAmgG63Entity> {
    public MercedesAmgG63Renderer(EntityRendererManager manager) {
        super(manager, new MercedesAmgG63Model(), "mercedes_amg_g63");
    }
}
