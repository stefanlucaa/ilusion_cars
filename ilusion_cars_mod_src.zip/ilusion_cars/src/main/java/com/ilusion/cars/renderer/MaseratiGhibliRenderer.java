package com.ilusion.cars.renderer;

import com.ilusion.cars.entity.MaseratiGhibliEntity;
import com.ilusion.cars.model.MaseratiGhibliModel;
import net.minecraft.client.renderer.entity.EntityRendererManager;

public class MaseratiGhibliRenderer extends BaseCarRenderer<MaseratiGhibliEntity> {
    public MaseratiGhibliRenderer(EntityRendererManager manager) {
        super(manager, new MaseratiGhibliModel(), "maserati_ghibli");
    }
}
