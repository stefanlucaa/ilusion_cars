package com.ilusion.cars;

import com.ilusion.cars.command.SummonCarCommand;
import com.ilusion.cars.init.EntityInit;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Mod("ilusioncar")
public class IlusionCarsMod {

    public static final String MOD_ID = "ilusioncar";
    public static final Logger LOGGER = LogManager.getLogger();

    public IlusionCarsMod() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        EntityInit.ENTITY_TYPES.register(modBus);
        modBus.addListener(ClientSetup::init);
        MinecraftForge.EVENT_BUS.register(this);
    }

    @SubscribeEvent
    public void onRegisterCommands(RegisterCommandsEvent event) {
        SummonCarCommand.register(event.getDispatcher());
        LOGGER.info("[IlusionCars] Comenzi inregistrate! Foloseste /summon ils.<NumeMasina>");
    }
}
