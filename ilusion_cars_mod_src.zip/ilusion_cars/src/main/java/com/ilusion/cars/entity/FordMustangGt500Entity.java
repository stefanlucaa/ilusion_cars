package com.ilusion.cars.entity;

import com.ilusion.cars.init.EntityInit;
import net.minecraft.entity.EntityType;
import net.minecraft.world.World;

/** Ford Mustang GT500 */
public class FordMustangGt500Entity extends BaseCarEntity {

    public FordMustangGt500Entity(EntityType<? extends BaseCarEntity> type, World world) {
        super(type, world);
        this.maxSpeed  = 1.00f;
        this.accel     = 0.07f;
        this.turnSpeed = 5.0f;
        this.hasSiren  = false;
    }
}
