package com.ilusion.cars.model;

import com.ilusion.cars.entity.BentleyContinentalEntity;

public class BentleyContinentalModel extends BaseCarModel<BentleyContinentalEntity> {

    @Override
    protected void buildParts() {
        setupParts(
            25,   // body half-length
            12,   // body half-width
            3,   // body bottom y
            6,   // body top y
            10,   // cabin top y
            false,
            false
        );
    }
}
