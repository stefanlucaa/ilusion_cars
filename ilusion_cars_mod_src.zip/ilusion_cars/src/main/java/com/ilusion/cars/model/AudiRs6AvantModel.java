package com.ilusion.cars.model;

import com.ilusion.cars.entity.AudiRs6AvantEntity;

public class AudiRs6AvantModel extends BaseCarModel<AudiRs6AvantEntity> {

    @Override
    protected void buildParts() {
        setupParts(
            24,   // body half-length
            11,   // body half-width
            3,   // body bottom y
            7,   // body top y
            10,   // cabin top y
            false,
            false
        );
    }
}
