package com.ilusion.cars.entity;

import com.ilusion.cars.init.EntityInit;
import net.minecraft.entity.EntityType;
import net.minecraft.world.World;

/** BMW M5 Competition */
public class BmwM5CompetitionEntity extends BaseCarEntity {

    public BmwM5CompetitionEntity(EntityType<? extends BaseCarEntity> type, World world) {
        super(type, world);
        this.maxSpeed  = 0.95f;
        this.accel     = 0.065f;
        this.turnSpeed = 5.0f;
        this.hasSiren  = false;
    }
}
