package com.ilusion.cars.renderer;

import com.ilusion.cars.entity.RollsRoyceGhostEntity;
import com.ilusion.cars.model.RollsRoyceGhostModel;
import net.minecraft.client.renderer.entity.EntityRendererManager;

public class RollsRoyceGhostRenderer extends BaseCarRenderer<RollsRoyceGhostEntity> {
    public RollsRoyceGhostRenderer(EntityRendererManager manager) {
        super(manager, new RollsRoyceGhostModel(), "rolls_royce_ghost");
    }
}
