package com.ilusion.cars.renderer;

import com.ilusion.cars.entity.PolitieBmwSeria5Entity;
import com.ilusion.cars.model.PolitieBmwSeria5Model;
import net.minecraft.client.renderer.entity.EntityRendererManager;

public class PolitieBmwSeria5Renderer extends BaseCarRenderer<PolitieBmwSeria5Entity> {
    public PolitieBmwSeria5Renderer(EntityRendererManager manager) {
        super(manager, new PolitieBmwSeria5Model(), "politie_bmw_seria5");
    }
}
