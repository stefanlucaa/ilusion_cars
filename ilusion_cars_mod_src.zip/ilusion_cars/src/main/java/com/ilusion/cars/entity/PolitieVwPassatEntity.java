package com.ilusion.cars.entity;

import com.ilusion.cars.init.EntityInit;
import net.minecraft.entity.EntityType;
import net.minecraft.world.World;

/** Politie VW Passat */
public class PolitieVwPassatEntity extends BaseCarEntity {

    public PolitieVwPassatEntity(EntityType<? extends BaseCarEntity> type, World world) {
        super(type, world);
        this.maxSpeed  = 0.60f;
        this.accel     = 0.038f;
        this.turnSpeed = 4.2f;
        this.hasSiren  = true;
    }
}
