package com.ilusion.cars.entity;

import com.ilusion.cars.init.EntityInit;
import net.minecraft.entity.EntityType;
import net.minecraft.world.World;

/** DIICOT Logan MCV */
public class DiicotLoganMcvEntity extends BaseCarEntity {

    public DiicotLoganMcvEntity(EntityType<? extends BaseCarEntity> type, World world) {
        super(type, world);
        this.maxSpeed  = 0.58f;
        this.accel     = 0.036f;
        this.turnSpeed = 4.0f;
        this.hasSiren  = true;
    }
}
