package com.ilusion.cars;

import com.ilusion.cars.init.EntityInit;
import com.ilusion.cars.renderer.*;
import net.minecraftforge.fml.client.registry.RenderingRegistry;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;

public class ClientSetup {

    public static void init(final FMLClientSetupEvent event) {
        RenderingRegistry.registerEntityRenderingHandler(EntityInit.POLITIEDACIALOGAN.get(), PolitieDaciaLoganRenderer::new);
        RenderingRegistry.registerEntityRenderingHandler(EntityInit.POLITIEBMWSERIA5.get(),  PolitieBmwSeria5Renderer::new);
        RenderingRegistry.registerEntityRenderingHandler(EntityInit.POLITIEVWPASSAT.get(),   PolitieVwPassatRenderer::new);
        RenderingRegistry.registerEntityRenderingHandler(EntityInit.SMURDAMBULANTA.get(),    SmurdAmbulantaRenderer::new);
        RenderingRegistry.registerEntityRenderingHandler(EntityInit.DIICOTDUSTER.get(),      DiicotDusterRenderer::new);
        RenderingRegistry.registerEntityRenderingHandler(EntityInit.DIICOTLOGANMCV.get(),    DiicotLoganMcvRenderer::new);
        RenderingRegistry.registerEntityRenderingHandler(EntityInit.BUGATTICHRON.get(),      BugattiChironRenderer::new);
        RenderingRegistry.registerEntityRenderingHandler(EntityInit.LAMBORGHINIHURACAN.get(),LamborghiniHuracanRenderer::new);
        RenderingRegistry.registerEntityRenderingHandler(EntityInit.FERRARYSF90.get(),       FerrariSf90Renderer::new);
        RenderingRegistry.registerEntityRenderingHandler(EntityInit.MCLAREN720S.get(),       McLaren720sRenderer::new);
        RenderingRegistry.registerEntityRenderingHandler(EntityInit.PORSCHE911GT3.get(),     Porsche911Gt3Renderer::new);
        RenderingRegistry.registerEntityRenderingHandler(EntityInit.MERCEDESAMGG63.get(),    MercedesAmgG63Renderer::new);
        RenderingRegistry.registerEntityRenderingHandler(EntityInit.RANGEROVERSVR.get(),     RangeRoverSvrRenderer::new);
        RenderingRegistry.registerEntityRenderingHandler(EntityInit.BMWM5COMPETITION.get(),  BmwM5CompetitionRenderer::new);
        RenderingRegistry.registerEntityRenderingHandler(EntityInit.AUDIRS6AVANT.get(),      AudiRs6AvantRenderer::new);
        RenderingRegistry.registerEntityRenderingHandler(EntityInit.MERCEDESCLS63.get(),     MercedesCls63Renderer::new);
        RenderingRegistry.registerEntityRenderingHandler(EntityInit.ASTONMARTINDB11.get(),   AstonMartinDb11Renderer::new);
        RenderingRegistry.registerEntityRenderingHandler(EntityInit.BENTLEYCONTINENTAL.get(),BentleyContinentalRenderer::new);
        RenderingRegistry.registerEntityRenderingHandler(EntityInit.ROLLSROYCEGHOST.get(),   RollsRoyceGhostRenderer::new);
        RenderingRegistry.registerEntityRenderingHandler(EntityInit.CADILLACESCALADE.get(),  CadillacEscaladeRenderer::new);
        RenderingRegistry.registerEntityRenderingHandler(EntityInit.DODGECHALLENGERRT.get(), DodgeChallengerRtRenderer::new);
        RenderingRegistry.registerEntityRenderingHandler(EntityInit.FORDMUSTANGGT500.get(),  FordMustangGt500Renderer::new);
        RenderingRegistry.registerEntityRenderingHandler(EntityInit.CHEVROLETCORVETTE.get(), ChevroletCorvetteRenderer::new);
        RenderingRegistry.registerEntityRenderingHandler(EntityInit.BMWM8GRANCOUPE.get(),    BmwM8GranCoupeRenderer::new);
        RenderingRegistry.registerEntityRenderingHandler(EntityInit.PORSCHECAYENNEGTS.get(), PorscheCayenneGtsRenderer::new);
        RenderingRegistry.registerEntityRenderingHandler(EntityInit.TESLAMODELSPLAID.get(),  TeslaModelSPlaidRenderer::new);
        RenderingRegistry.registerEntityRenderingHandler(EntityInit.AUDIR8V10.get(),         AudiR8V10Renderer::new);
        RenderingRegistry.registerEntityRenderingHandler(EntityInit.MERCEDESMAYBACKHS.get(), MercedesMaybachSRenderer::new);
        RenderingRegistry.registerEntityRenderingHandler(EntityInit.BMWX5M.get(),            BmwX5mRenderer::new);
        RenderingRegistry.registerEntityRenderingHandler(EntityInit.MASERATIGIBBLI.get(),    MaseratiGhibliRenderer::new);
        RenderingRegistry.registerEntityRenderingHandler(EntityInit.VOLKSWAGENGOLFR.get(),   VolkswagenGolfRRenderer::new);
        RenderingRegistry.registerEntityRenderingHandler(EntityInit.HONDACIVICTYPER.get(),   HondaCivicTypeRRenderer::new);
        RenderingRegistry.registerEntityRenderingHandler(EntityInit.NISSANGTRR35.get(),      NissanGtrR35Renderer::new);
        RenderingRegistry.registerEntityRenderingHandler(EntityInit.SUBARUIMPREZAWRX.get(),  SubaruImprezaWrxRenderer::new);
        RenderingRegistry.registerEntityRenderingHandler(EntityInit.TOYOTASUPRAMK5.get(),    ToyotaSupraMk5Renderer::new);
    }
}
