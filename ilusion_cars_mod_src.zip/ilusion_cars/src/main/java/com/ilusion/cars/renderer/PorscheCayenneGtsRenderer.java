package com.ilusion.cars.renderer;

import com.ilusion.cars.entity.PorscheCayenneGtsEntity;
import com.ilusion.cars.model.PorscheCayenneGtsModel;
import net.minecraft.client.renderer.entity.EntityRendererManager;

public class PorscheCayenneGtsRenderer extends BaseCarRenderer<PorscheCayenneGtsEntity> {
    public PorscheCayenneGtsRenderer(EntityRendererManager manager) {
        super(manager, new PorscheCayenneGtsModel(), "porsche_cayenne_gts");
    }
}
