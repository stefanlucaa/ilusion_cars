package com.ilusion.cars.entity;

import com.ilusion.cars.init.EntityInit;
import net.minecraft.entity.EntityType;
import net.minecraft.world.World;

/** Bentley Continental */
public class BentleyContinentalEntity extends BaseCarEntity {

    public BentleyContinentalEntity(EntityType<? extends BaseCarEntity> type, World world) {
        super(type, world);
        this.maxSpeed  = 0.95f;
        this.accel     = 0.065f;
        this.turnSpeed = 4.8f;
        this.hasSiren  = false;
    }
}
