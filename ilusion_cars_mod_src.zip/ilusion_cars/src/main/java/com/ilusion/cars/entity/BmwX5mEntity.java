package com.ilusion.cars.entity;

import com.ilusion.cars.init.EntityInit;
import net.minecraft.entity.EntityType;
import net.minecraft.world.World;

/** BMW X5M */
public class BmwX5mEntity extends BaseCarEntity {

    public BmwX5mEntity(EntityType<? extends BaseCarEntity> type, World world) {
        super(type, world);
        this.maxSpeed  = 0.90f;
        this.accel     = 0.060f;
        this.turnSpeed = 4.5f;
        this.hasSiren  = false;
    }
}
