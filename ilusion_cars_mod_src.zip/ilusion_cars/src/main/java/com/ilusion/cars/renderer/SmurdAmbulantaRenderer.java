package com.ilusion.cars.renderer;

import com.ilusion.cars.entity.SmurdAmbulantaEntity;
import com.ilusion.cars.model.SmurdAmbulantaModel;
import net.minecraft.client.renderer.entity.EntityRendererManager;

public class SmurdAmbulantaRenderer extends BaseCarRenderer<SmurdAmbulantaEntity> {
    public SmurdAmbulantaRenderer(EntityRendererManager manager) {
        super(manager, new SmurdAmbulantaModel(), "smurd_ambulanta");
    }
}
