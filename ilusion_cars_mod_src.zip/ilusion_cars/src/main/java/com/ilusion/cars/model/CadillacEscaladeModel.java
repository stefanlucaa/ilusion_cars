package com.ilusion.cars.model;

import com.ilusion.cars.entity.CadillacEscaladeEntity;

public class CadillacEscaladeModel extends BaseCarModel<CadillacEscaladeEntity> {

    @Override
    protected void buildParts() {
        setupParts(
            25,   // body half-length
            13,   // body half-width
            3,   // body bottom y
            9,   // body top y
            12,   // cabin top y
            false,
            false
        );
    }
}
