package com.ilusion.cars.entity;

import com.ilusion.cars.init.EntityInit;
import net.minecraft.entity.EntityType;
import net.minecraft.world.World;

/** Tesla Model S Plaid */
public class TeslaModelSPlaidEntity extends BaseCarEntity {

    public TeslaModelSPlaidEntity(EntityType<? extends BaseCarEntity> type, World world) {
        super(type, world);
        this.maxSpeed  = 1.10f;
        this.accel     = 0.09f;
        this.turnSpeed = 5.5f;
        this.hasSiren  = false;
    }
}
