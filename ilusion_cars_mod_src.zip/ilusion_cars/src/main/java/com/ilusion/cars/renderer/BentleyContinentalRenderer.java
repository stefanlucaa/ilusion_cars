package com.ilusion.cars.renderer;

import com.ilusion.cars.entity.BentleyContinentalEntity;
import com.ilusion.cars.model.BentleyContinentalModel;
import net.minecraft.client.renderer.entity.EntityRendererManager;

public class BentleyContinentalRenderer extends BaseCarRenderer<BentleyContinentalEntity> {
    public BentleyContinentalRenderer(EntityRendererManager manager) {
        super(manager, new BentleyContinentalModel(), "bentley_continental");
    }
}
