package com.ilusion.cars.entity;

import com.ilusion.cars.init.EntityInit;
import net.minecraft.entity.EntityType;
import net.minecraft.world.World;

/** Porsche 911 GT3 */
public class Porsche911Gt3Entity extends BaseCarEntity {

    public Porsche911Gt3Entity(EntityType<? extends BaseCarEntity> type, World world) {
        super(type, world);
        this.maxSpeed  = 1.05f;
        this.accel     = 0.07f;
        this.turnSpeed = 5.0f;
        this.hasSiren  = false;
    }
}
