package com.ilusion.cars.model;

import com.ilusion.cars.entity.PolitieVwPassatEntity;

public class PolitieVwPassatModel extends BaseCarModel<PolitieVwPassatEntity> {

    @Override
    protected void buildParts() {
        setupParts(
            23,   // body half-length
            11,   // body half-width
            3,   // body bottom y
            6,   // body top y
            10,   // cabin top y
            false,
            true
        );
    }
}
