package com.ilusion.cars.command;

import com.ilusion.cars.init.EntityInit;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import net.minecraft.command.CommandSource;
import net.minecraft.command.Commands;
import net.minecraft.command.ISuggestionProvider;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.util.text.TextFormatting;
import net.minecraftforge.fml.RegistryObject;

import java.util.*;

/**
 * Registers the command:
 *   /summon ils.<CarName>
 * e.g. /summon ils.BugattiChiron
 *      /summon ils.PolitieDaciaLogan
 */
public class SummonCarCommand {

    // Map from "ils.<Name>" → RegistryObject<EntityType>
    private static final Map<String, RegistryObject<?>> CAR_MAP = new LinkedHashMap<>();

    static {
        CAR_MAP.put("ils.PolitieDaciaLogan",   EntityInit.POLITIEDACIALOGAN);
        CAR_MAP.put("ils.PolitieBmwSeria5",    EntityInit.POLITIEBMWSERIA5);
        CAR_MAP.put("ils.PolitieVwPassat",     EntityInit.POLITIEVWPASSAT);
        CAR_MAP.put("ils.SmurdAmbulanta",      EntityInit.SMURDAMBULANTA);
        CAR_MAP.put("ils.DiicotDuster",        EntityInit.DIICOTDUSTER);
        CAR_MAP.put("ils.DiicotLoganMcv",      EntityInit.DIICOTLOGANMCV);
        CAR_MAP.put("ils.BugattiChiron",       EntityInit.BUGATTICHRON);
        CAR_MAP.put("ils.LamborghiniHuracan",  EntityInit.LAMBORGHINIHURACAN);
        CAR_MAP.put("ils.FerrariSf90",         EntityInit.FERRARYSF90);
        CAR_MAP.put("ils.McLaren720s",         EntityInit.MCLAREN720S);
        CAR_MAP.put("ils.Porsche911Gt3",       EntityInit.PORSCHE911GT3);
        CAR_MAP.put("ils.MercedesAmgG63",      EntityInit.MERCEDESAMGG63);
        CAR_MAP.put("ils.RangeRoverSvr",       EntityInit.RANGEROVERSVR);
        CAR_MAP.put("ils.BmwM5Competition",    EntityInit.BMWM5COMPETITION);
        CAR_MAP.put("ils.AudiRs6Avant",        EntityInit.AUDIRS6AVANT);
        CAR_MAP.put("ils.MercedesCls63",       EntityInit.MERCEDESCLS63);
        CAR_MAP.put("ils.AstonMartinDb11",     EntityInit.ASTONMARTINDB11);
        CAR_MAP.put("ils.BentleyContinental",  EntityInit.BENTLEYCONTINENTAL);
        CAR_MAP.put("ils.RollsRoyceGhost",     EntityInit.ROLLSROYCEGHOST);
        CAR_MAP.put("ils.CadillacEscalade",    EntityInit.CADILLACESCALADE);
        CAR_MAP.put("ils.DodgeChallengerRt",   EntityInit.DODGECHALLENGERRT);
        CAR_MAP.put("ils.FordMustangGt500",    EntityInit.FORDMUSTANGGT500);
        CAR_MAP.put("ils.ChevroletCorvette",   EntityInit.CHEVROLETCORVETTE);
        CAR_MAP.put("ils.BmwM8GranCoupe",      EntityInit.BMWM8GRANCOUPE);
        CAR_MAP.put("ils.PorscheCayenneGts",   EntityInit.PORSCHECAYENNEGTS);
        CAR_MAP.put("ils.TeslaModelSPlaid",    EntityInit.TESLAMODELSPLAID);
        CAR_MAP.put("ils.AudiR8V10",           EntityInit.AUDIR8V10);
        CAR_MAP.put("ils.MercedesMaybachS",    EntityInit.MERCEDESMAYBACKHS);
        CAR_MAP.put("ils.BmwX5m",              EntityInit.BMWX5M);
        CAR_MAP.put("ils.MaseratiGhibli",      EntityInit.MASERATIGIBBLI);
        CAR_MAP.put("ils.VolkswagenGolfR",     EntityInit.VOLKSWAGENGOLFR);
        CAR_MAP.put("ils.HondaCivicTypeR",     EntityInit.HONDACIVICTYPER);
        CAR_MAP.put("ils.NissanGtrR35",        EntityInit.NISSANGTRR35);
        CAR_MAP.put("ils.SubaruImprezaWrx",    EntityInit.SUBARUIMPREZAWRX);
        CAR_MAP.put("ils.ToyotaSupraMk5",      EntityInit.TOYOTASUPRAMK5);
    }

    private static final SuggestionProvider<CommandSource> SUGGESTIONS =
        (ctx, builder) -> ISuggestionProvider.suggest(CAR_MAP.keySet(), builder);

    public static void register(CommandDispatcher<CommandSource> dispatcher) {
        dispatcher.register(
            Commands.literal("summon")
                .then(Commands.argument("car", StringArgumentType.string())
                    .suggests(SUGGESTIONS)
                    .executes(ctx -> {
                        String carId = StringArgumentType.getString(ctx, "car");
                        return summonCar(ctx.getSource(), carId);
                    }))
        );
    }

    @SuppressWarnings({"unchecked","rawtypes"})
    private static int summonCar(CommandSource src, String carId) {
        RegistryObject<?> reg = CAR_MAP.get(carId);
        if (reg == null) {
            src.sendFailure(new StringTextComponent(
                TextFormatting.RED + "Masina necunoscuta: " + carId +
                "\nFoloseste /summon ils.<NumeMasina>"));
            return 0;
        }
        try {
            EntityType type  = (EntityType) reg.get();
            Entity     car   = type.create(src.getLevel());
            var        pos   = src.getPosition();
            if (car != null) {
                car.moveTo(pos.x, pos.y, pos.z, 0, 0);
                src.getLevel().addFreshEntity(car);
                src.sendSuccess(new StringTextComponent(
                    TextFormatting.GREEN + "✓ " + carId + " a aparut!"), true);
                return 1;
            }
        } catch (Exception e) {
            src.sendFailure(new StringTextComponent(
                TextFormatting.RED + "Eroare la summon: " + e.getMessage()));
        }
        return 0;
    }
}
