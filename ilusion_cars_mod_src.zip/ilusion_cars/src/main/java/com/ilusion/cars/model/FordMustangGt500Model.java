package com.ilusion.cars.model;

import com.ilusion.cars.entity.FordMustangGt500Entity;

public class FordMustangGt500Model extends BaseCarModel<FordMustangGt500Entity> {

    @Override
    protected void buildParts() {
        setupParts(
            24,   // body half-length
            11,   // body half-width
            3,   // body bottom y
            6,   // body top y
            10,   // cabin top y
            true,
            false
        );
    }
}
