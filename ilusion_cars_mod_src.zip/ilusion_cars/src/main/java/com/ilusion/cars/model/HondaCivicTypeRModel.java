package com.ilusion.cars.model;

import com.ilusion.cars.entity.HondaCivicTypeREntity;

public class HondaCivicTypeRModel extends BaseCarModel<HondaCivicTypeREntity> {

    @Override
    protected void buildParts() {
        setupParts(
            22,   // body half-length
            10,   // body half-width
            3,   // body bottom y
            6,   // body top y
            9,   // cabin top y
            true,
            false
        );
    }
}
