package com.ilusion.cars.renderer;

import com.ilusion.cars.entity.DodgeChallengerRtEntity;
import com.ilusion.cars.model.DodgeChallengerRtModel;
import net.minecraft.client.renderer.entity.EntityRendererManager;

public class DodgeChallengerRtRenderer extends BaseCarRenderer<DodgeChallengerRtEntity> {
    public DodgeChallengerRtRenderer(EntityRendererManager manager) {
        super(manager, new DodgeChallengerRtModel(), "dodge_challenger_rt");
    }
}
