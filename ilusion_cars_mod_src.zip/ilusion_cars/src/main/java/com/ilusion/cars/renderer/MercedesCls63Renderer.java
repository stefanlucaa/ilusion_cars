package com.ilusion.cars.renderer;

import com.ilusion.cars.entity.MercedesCls63Entity;
import com.ilusion.cars.model.MercedesCls63Model;
import net.minecraft.client.renderer.entity.EntityRendererManager;

public class MercedesCls63Renderer extends BaseCarRenderer<MercedesCls63Entity> {
    public MercedesCls63Renderer(EntityRendererManager manager) {
        super(manager, new MercedesCls63Model(), "mercedes_cls63");
    }
}
