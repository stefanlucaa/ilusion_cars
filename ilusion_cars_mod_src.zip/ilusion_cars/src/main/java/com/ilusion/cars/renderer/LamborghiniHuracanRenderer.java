package com.ilusion.cars.renderer;

import com.ilusion.cars.entity.LamborghiniHuracanEntity;
import com.ilusion.cars.model.LamborghiniHuracanModel;
import net.minecraft.client.renderer.entity.EntityRendererManager;

public class LamborghiniHuracanRenderer extends BaseCarRenderer<LamborghiniHuracanEntity> {
    public LamborghiniHuracanRenderer(EntityRendererManager manager) {
        super(manager, new LamborghiniHuracanModel(), "lamborghini_huracan");
    }
}
