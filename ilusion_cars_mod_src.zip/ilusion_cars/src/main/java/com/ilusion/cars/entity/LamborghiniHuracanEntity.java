package com.ilusion.cars.entity;

import com.ilusion.cars.init.EntityInit;
import net.minecraft.entity.EntityType;
import net.minecraft.world.World;

/** Lamborghini Huracan */
public class LamborghiniHuracanEntity extends BaseCarEntity {

    public LamborghiniHuracanEntity(EntityType<? extends BaseCarEntity> type, World world) {
        super(type, world);
        this.maxSpeed  = 1.15f;
        this.accel     = 0.08f;
        this.turnSpeed = 5.5f;
        this.hasSiren  = false;
    }
}
