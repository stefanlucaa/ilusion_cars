package com.ilusion.cars.renderer;

import com.ilusion.cars.entity.NissanGtrR35Entity;
import com.ilusion.cars.model.NissanGtrR35Model;
import net.minecraft.client.renderer.entity.EntityRendererManager;

public class NissanGtrR35Renderer extends BaseCarRenderer<NissanGtrR35Entity> {
    public NissanGtrR35Renderer(EntityRendererManager manager) {
        super(manager, new NissanGtrR35Model(), "nissan_gtr_r35");
    }
}
