package com.ilusion.cars.model;

import com.ilusion.cars.entity.MercedesMaybachSEntity;

public class MercedesMaybachSModel extends BaseCarModel<MercedesMaybachSEntity> {

    @Override
    protected void buildParts() {
        setupParts(
            27,   // body half-length
            13,   // body half-width
            3,   // body bottom y
            7,   // body top y
            11,   // cabin top y
            false,
            false
        );
    }
}
