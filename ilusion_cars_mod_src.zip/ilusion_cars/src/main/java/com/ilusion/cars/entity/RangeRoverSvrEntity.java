package com.ilusion.cars.entity;

import com.ilusion.cars.init.EntityInit;
import net.minecraft.entity.EntityType;
import net.minecraft.world.World;

/** Range Rover SVR */
public class RangeRoverSvrEntity extends BaseCarEntity {

    public RangeRoverSvrEntity(EntityType<? extends BaseCarEntity> type, World world) {
        super(type, world);
        this.maxSpeed  = 0.80f;
        this.accel     = 0.052f;
        this.turnSpeed = 4.0f;
        this.hasSiren  = false;
    }
}
