package com.ilusion.cars.renderer;

import com.ilusion.cars.entity.CadillacEscaladeEntity;
import com.ilusion.cars.model.CadillacEscaladeModel;
import net.minecraft.client.renderer.entity.EntityRendererManager;

public class CadillacEscaladeRenderer extends BaseCarRenderer<CadillacEscaladeEntity> {
    public CadillacEscaladeRenderer(EntityRendererManager manager) {
        super(manager, new CadillacEscaladeModel(), "cadillac_escalade");
    }
}
