package com.ilusion.cars.renderer;

import com.ilusion.cars.entity.DiicotLoganMcvEntity;
import com.ilusion.cars.model.DiicotLoganMcvModel;
import net.minecraft.client.renderer.entity.EntityRendererManager;

public class DiicotLoganMcvRenderer extends BaseCarRenderer<DiicotLoganMcvEntity> {
    public DiicotLoganMcvRenderer(EntityRendererManager manager) {
        super(manager, new DiicotLoganMcvModel(), "diicot_logan_mcv");
    }
}
