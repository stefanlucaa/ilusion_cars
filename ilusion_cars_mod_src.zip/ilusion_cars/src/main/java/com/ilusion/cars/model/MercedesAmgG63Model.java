package com.ilusion.cars.model;

import com.ilusion.cars.entity.MercedesAmgG63Entity;

public class MercedesAmgG63Model extends BaseCarModel<MercedesAmgG63Entity> {

    @Override
    protected void buildParts() {
        setupParts(
            22,   // body half-length
            12,   // body half-width
            3,   // body bottom y
            8,   // body top y
            12,   // cabin top y
            false,
            false
        );
    }
}
