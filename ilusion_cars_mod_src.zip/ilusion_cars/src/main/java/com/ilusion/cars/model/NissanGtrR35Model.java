package com.ilusion.cars.model;

import com.ilusion.cars.entity.NissanGtrR35Entity;

public class NissanGtrR35Model extends BaseCarModel<NissanGtrR35Entity> {

    @Override
    protected void buildParts() {
        setupParts(
            23,   // body half-length
            11,   // body half-width
            3,   // body bottom y
            6,   // body top y
            10,   // cabin top y
            true,
            false
        );
    }
}
