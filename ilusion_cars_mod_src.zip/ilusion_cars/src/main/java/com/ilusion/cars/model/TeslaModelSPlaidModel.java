package com.ilusion.cars.model;

import com.ilusion.cars.entity.TeslaModelSPlaidEntity;

public class TeslaModelSPlaidModel extends BaseCarModel<TeslaModelSPlaidEntity> {

    @Override
    protected void buildParts() {
        setupParts(
            25,   // body half-length
            11,   // body half-width
            3,   // body bottom y
            6,   // body top y
            10,   // cabin top y
            false,
            false
        );
    }
}
