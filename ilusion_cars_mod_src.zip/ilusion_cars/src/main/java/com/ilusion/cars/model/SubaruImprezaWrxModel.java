package com.ilusion.cars.model;

import com.ilusion.cars.entity.SubaruImprezaWrxEntity;

public class SubaruImprezaWrxModel extends BaseCarModel<SubaruImprezaWrxEntity> {

    @Override
    protected void buildParts() {
        setupParts(
            22,   // body half-length
            10,   // body half-width
            3,   // body bottom y
            6,   // body top y
            10,   // cabin top y
            true,
            false
        );
    }
}
