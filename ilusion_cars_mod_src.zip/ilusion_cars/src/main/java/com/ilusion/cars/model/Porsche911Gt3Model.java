package com.ilusion.cars.model;

import com.ilusion.cars.entity.Porsche911Gt3Entity;

public class Porsche911Gt3Model extends BaseCarModel<Porsche911Gt3Entity> {

    @Override
    protected void buildParts() {
        setupParts(
            23,   // body half-length
            10,   // body half-width
            2,   // body bottom y
            5,   // body top y
            9,   // cabin top y
            true,
            false
        );
    }
}
