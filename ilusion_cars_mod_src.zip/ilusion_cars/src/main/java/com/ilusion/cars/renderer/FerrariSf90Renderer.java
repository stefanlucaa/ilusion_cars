package com.ilusion.cars.renderer;

import com.ilusion.cars.entity.FerrariSf90Entity;
import com.ilusion.cars.model.FerrariSf90Model;
import net.minecraft.client.renderer.entity.EntityRendererManager;

public class FerrariSf90Renderer extends BaseCarRenderer<FerrariSf90Entity> {
    public FerrariSf90Renderer(EntityRendererManager manager) {
        super(manager, new FerrariSf90Model(), "ferrari_sf90");
    }
}
