package com.ilusion.cars.renderer;

import com.ilusion.cars.entity.BmwM8GranCoupeEntity;
import com.ilusion.cars.model.BmwM8GranCoupeModel;
import net.minecraft.client.renderer.entity.EntityRendererManager;

public class BmwM8GranCoupeRenderer extends BaseCarRenderer<BmwM8GranCoupeEntity> {
    public BmwM8GranCoupeRenderer(EntityRendererManager manager) {
        super(manager, new BmwM8GranCoupeModel(), "bmw_m8_gran_coupe");
    }
}
