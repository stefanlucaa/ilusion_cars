package com.ilusion.cars.entity;

import net.minecraft.entity.*;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.CompoundNBT;
import net.minecraft.network.datasync.*;
import net.minecraft.util.*;
import net.minecraft.world.World;

import javax.annotation.Nullable;

/**
 * Base class for all Ilusion Cars Pack vehicles.
 * Players can right-click to sit in the car.
 * The car steers with WASD while mounted.
 */
public abstract class BaseCarEntity extends Entity {

    protected static final DataParameter<Float> SPEED =
        EntityDataManager.defineId(BaseCarEntity.class, DataSerializers.FLOAT);
    protected static final DataParameter<Boolean> BOOST =
        EntityDataManager.defineId(BaseCarEntity.class, DataSerializers.BOOLEAN);

    // Configurable per car type
    public float maxSpeed   = 0.6f;
    public float accel      = 0.04f;
    public float turnSpeed  = 4.0f;
    public boolean hasSiren = false;

    private float currentSpeed = 0f;
    private float currentYaw   = 0f;

    public BaseCarEntity(EntityType<? extends BaseCarEntity> type, World world) {
        super(type, world);
        this.noCulling = true;
        this.blocksBuilding = true;
    }

    @Override
    protected void defineSynchedData() {
        this.entityData.define(SPEED, 0f);
        this.entityData.define(BOOST, false);
    }

    @Override
    public ActionResultType interact(PlayerEntity player, Hand hand) {
        if (!this.level.isClientSide) {
            if (this.getPassengers().isEmpty()) {
                player.startRiding(this);
                return ActionResultType.SUCCESS;
            }
        }
        return ActionResultType.PASS;
    }

    @Override
    public void tick() {
        super.tick();
        if (!this.level.isClientSide && this.isVehicle()) {
            Entity driver = this.getControllingPassenger();
            if (driver instanceof PlayerEntity) {
                handleDriving((PlayerEntity) driver);
            }
        }
        // Apply gravity
        if (!this.isOnGround()) {
            this.setDeltaMovement(this.getDeltaMovement().add(0, -0.08, 0));
        }
        this.move(MoverType.SELF, this.getDeltaMovement());
        this.setDeltaMovement(this.getDeltaMovement().scale(0.9));
    }

    private void handleDriving(PlayerEntity player) {
        float forward  = -player.zza;   // 1 = W, -1 = S
        float strafe   = player.xxa;    // 1 = A, -1 = D
        float yaw      = player.yHeadRot;

        if (forward != 0) {
            currentSpeed += forward * accel;
            currentSpeed  = Math.max(-maxSpeed * 0.5f, Math.min(maxSpeed, currentSpeed));
        } else {
            currentSpeed *= 0.85f;
        }

        if (Math.abs(currentSpeed) > 0.01f) {
            currentYaw += strafe * turnSpeed * Math.signum(currentSpeed);
        }

        this.setYRot(currentYaw);
        this.yHeadRot = currentYaw;

        double dx = -Math.sin(Math.toRadians(currentYaw)) * currentSpeed;
        double dz =  Math.cos(Math.toRadians(currentYaw)) * currentSpeed;
        this.setDeltaMovement(dx, this.getDeltaMovement().y, dz);
    }

    @Override
    @Nullable
    public Entity getControllingPassenger() {
        return this.getPassengers().isEmpty() ? null : this.getPassengers().get(0);
    }

    @Override
    public boolean canBeCollidedWith() { return true; }

    @Override
    public boolean isPushable() { return false; }

    @Override
    protected boolean canRide(Entity entity) { return true; }

    @Override
    public void positionRider(Entity passenger) {
        if (this.hasPassenger(passenger)) {
            passenger.setPos(
                this.getX(),
                this.getY() + this.getPassengersRidingOffset() + passenger.getMyRidingOffset(),
                this.getZ()
            );
        }
    }

    @Override
    public double getPassengersRidingOffset() { return 0.6; }

    @Override
    protected void readAdditionalSaveData(CompoundNBT nbt) {
        currentSpeed = nbt.getFloat("currentSpeed");
        currentYaw   = nbt.getFloat("currentYaw");
    }

    @Override
    protected void addAdditionalSaveData(CompoundNBT nbt) {
        nbt.putFloat("currentSpeed", currentSpeed);
        nbt.putFloat("currentYaw",   currentYaw);
    }
}
