package com.ilusion.cars.renderer;

import com.ilusion.cars.IlusionCarsMod;
import com.ilusion.cars.entity.BaseCarEntity;
import com.ilusion.cars.model.BaseCarModel;
import com.mojang.blaze3d.matrix.MatrixStack;
import net.minecraft.client.renderer.IRenderTypeBuffer;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererManager;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.vector.Vector3f;

public class BaseCarRenderer<T extends BaseCarEntity> extends EntityRenderer<T> {

    private final BaseCarModel<T> model;
    private final ResourceLocation texture;

    public BaseCarRenderer(EntityRendererManager manager,
                           BaseCarModel<T> model,
                           String textureName) {
        super(manager);
        this.model   = model;
        this.texture = new ResourceLocation(IlusionCarsMod.MOD_ID,
                           "textures/entity/" + textureName + ".png");
    }

    @Override
    public void render(T entity, float yaw, float partialTick,
                       MatrixStack ms, IRenderTypeBuffer buf, int packedLight) {
        ms.pushPose();

        // Scale to ~2 blocks wide
        ms.scale(0.0625f, 0.0625f, 0.0625f);

        // Rotate so car faces the right direction
        ms.mulPose(Vector3f.YP.rotationDegrees(180f - entity.yRot));

        // Slight vertical offset so car sits on ground
        ms.translate(0, -1.5, 0);

        var vertexConsumer = buf.getBuffer(RenderType.entityCutoutNoCull(texture));
        model.renderToBuffer(ms, vertexConsumer, packedLight,
            OverlayTexture.NO_OVERLAY, 1f, 1f, 1f, 1f);

        ms.popPose();
        super.render(entity, yaw, partialTick, ms, buf, packedLight);
    }

    @Override
    public ResourceLocation getTextureLocation(T entity) {
        return texture;
    }
}
