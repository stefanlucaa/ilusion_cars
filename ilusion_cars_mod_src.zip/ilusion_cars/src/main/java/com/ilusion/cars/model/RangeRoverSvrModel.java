package com.ilusion.cars.model;

import com.ilusion.cars.entity.RangeRoverSvrEntity;

public class RangeRoverSvrModel extends BaseCarModel<RangeRoverSvrEntity> {

    @Override
    protected void buildParts() {
        setupParts(
            23,   // body half-length
            12,   // body half-width
            3,   // body bottom y
            8,   // body top y
            12,   // cabin top y
            false,
            false
        );
    }
}
