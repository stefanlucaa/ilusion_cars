package com.ilusion.cars.entity;

import com.ilusion.cars.init.EntityInit;
import net.minecraft.entity.EntityType;
import net.minecraft.world.World;

/** Audi RS6 Avant */
public class AudiRs6AvantEntity extends BaseCarEntity {

    public AudiRs6AvantEntity(EntityType<? extends BaseCarEntity> type, World world) {
        super(type, world);
        this.maxSpeed  = 0.90f;
        this.accel     = 0.060f;
        this.turnSpeed = 4.8f;
        this.hasSiren  = false;
    }
}
