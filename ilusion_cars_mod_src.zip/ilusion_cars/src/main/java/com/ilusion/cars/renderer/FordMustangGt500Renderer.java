package com.ilusion.cars.renderer;

import com.ilusion.cars.entity.FordMustangGt500Entity;
import com.ilusion.cars.model.FordMustangGt500Model;
import net.minecraft.client.renderer.entity.EntityRendererManager;

public class FordMustangGt500Renderer extends BaseCarRenderer<FordMustangGt500Entity> {
    public FordMustangGt500Renderer(EntityRendererManager manager) {
        super(manager, new FordMustangGt500Model(), "ford_mustang_gt500");
    }
}
