package com.ilusion.cars.model;

import com.ilusion.cars.entity.PorscheCayenneGtsEntity;

public class PorscheCayenneGtsModel extends BaseCarModel<PorscheCayenneGtsEntity> {

    @Override
    protected void buildParts() {
        setupParts(
            23,   // body half-length
            12,   // body half-width
            3,   // body bottom y
            8,   // body top y
            11,   // cabin top y
            false,
            false
        );
    }
}
