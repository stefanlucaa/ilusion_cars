package com.ilusion.cars.renderer;

import com.ilusion.cars.entity.AudiRs6AvantEntity;
import com.ilusion.cars.model.AudiRs6AvantModel;
import net.minecraft.client.renderer.entity.EntityRendererManager;

public class AudiRs6AvantRenderer extends BaseCarRenderer<AudiRs6AvantEntity> {
    public AudiRs6AvantRenderer(EntityRendererManager manager) {
        super(manager, new AudiRs6AvantModel(), "audi_rs6_avant");
    }
}
