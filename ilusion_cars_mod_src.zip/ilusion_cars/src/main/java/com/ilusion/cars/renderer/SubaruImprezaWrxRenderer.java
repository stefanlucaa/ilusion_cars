package com.ilusion.cars.renderer;

import com.ilusion.cars.entity.SubaruImprezaWrxEntity;
import com.ilusion.cars.model.SubaruImprezaWrxModel;
import net.minecraft.client.renderer.entity.EntityRendererManager;

public class SubaruImprezaWrxRenderer extends BaseCarRenderer<SubaruImprezaWrxEntity> {
    public SubaruImprezaWrxRenderer(EntityRendererManager manager) {
        super(manager, new SubaruImprezaWrxModel(), "subaru_impreza_wrx");
    }
}
