package com.ilusion.cars.entity;

import com.ilusion.cars.init.EntityInit;
import net.minecraft.entity.EntityType;
import net.minecraft.world.World;

/** Volkswagen Golf R */
public class VolkswagenGolfREntity extends BaseCarEntity {

    public VolkswagenGolfREntity(EntityType<? extends BaseCarEntity> type, World world) {
        super(type, world);
        this.maxSpeed  = 0.88f;
        this.accel     = 0.060f;
        this.turnSpeed = 5.0f;
        this.hasSiren  = false;
    }
}
