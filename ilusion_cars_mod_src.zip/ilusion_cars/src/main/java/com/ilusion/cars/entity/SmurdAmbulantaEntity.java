package com.ilusion.cars.entity;

import com.ilusion.cars.init.EntityInit;
import net.minecraft.entity.EntityType;
import net.minecraft.world.World;

/** SMURD Ambulanta */
public class SmurdAmbulantaEntity extends BaseCarEntity {

    public SmurdAmbulantaEntity(EntityType<? extends BaseCarEntity> type, World world) {
        super(type, world);
        this.maxSpeed  = 0.60f;
        this.accel     = 0.038f;
        this.turnSpeed = 3.8f;
        this.hasSiren  = true;
    }
}
