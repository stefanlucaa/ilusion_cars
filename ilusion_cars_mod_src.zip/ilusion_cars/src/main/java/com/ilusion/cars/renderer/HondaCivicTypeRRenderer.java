package com.ilusion.cars.renderer;

import com.ilusion.cars.entity.HondaCivicTypeREntity;
import com.ilusion.cars.model.HondaCivicTypeRModel;
import net.minecraft.client.renderer.entity.EntityRendererManager;

public class HondaCivicTypeRRenderer extends BaseCarRenderer<HondaCivicTypeREntity> {
    public HondaCivicTypeRRenderer(EntityRendererManager manager) {
        super(manager, new HondaCivicTypeRModel(), "honda_civic_type_r");
    }
}
