package com.ilusion.cars.entity;

import com.ilusion.cars.init.EntityInit;
import net.minecraft.entity.EntityType;
import net.minecraft.world.World;

/** Toyota Supra MK5 */
public class ToyotaSupraMk5Entity extends BaseCarEntity {

    public ToyotaSupraMk5Entity(EntityType<? extends BaseCarEntity> type, World world) {
        super(type, world);
        this.maxSpeed  = 1.00f;
        this.accel     = 0.070f;
        this.turnSpeed = 5.2f;
        this.hasSiren  = false;
    }
}
