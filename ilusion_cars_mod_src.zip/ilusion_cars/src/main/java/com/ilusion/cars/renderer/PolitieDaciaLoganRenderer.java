package com.ilusion.cars.renderer;

import com.ilusion.cars.entity.PolitieDaciaLoganEntity;
import com.ilusion.cars.model.PolitieDaciaLoganModel;
import net.minecraft.client.renderer.entity.EntityRendererManager;

public class PolitieDaciaLoganRenderer extends BaseCarRenderer<PolitieDaciaLoganEntity> {
    public PolitieDaciaLoganRenderer(EntityRendererManager manager) {
        super(manager, new PolitieDaciaLoganModel(), "politie_dacia_logan");
    }
}
