package com.ilusion.cars.entity;

import com.ilusion.cars.init.EntityInit;
import net.minecraft.entity.EntityType;
import net.minecraft.world.World;

/** Mercedes AMG G63 */
public class MercedesAmgG63Entity extends BaseCarEntity {

    public MercedesAmgG63Entity(EntityType<? extends BaseCarEntity> type, World world) {
        super(type, world);
        this.maxSpeed  = 0.85f;
        this.accel     = 0.055f;
        this.turnSpeed = 4.0f;
        this.hasSiren  = false;
    }
}
