package com.ilusion.cars.init;

import com.ilusion.cars.IlusionCarsMod;
import com.ilusion.cars.entity.*;
import net.minecraft.entity.EntityClassification;
import net.minecraft.entity.EntityType;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;

public class EntityInit {

    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES =
        DeferredRegister.create(ForgeRegistries.ENTITIES, IlusionCarsMod.MOD_ID);

    public static final RegistryObject<EntityType<PolitieDaciaLoganEntity>> POLITIEDACIALOGAN =
        ENTITY_TYPES.register("politie_dacia_logan",
            () -> EntityType.Builder.<PolitieDaciaLoganEntity>of(PolitieDaciaLoganEntity::new, EntityClassification.MISC)
                .sized(2.0f, 1.0f)
                .build(new ResourceLocation(IlusionCarsMod.MOD_ID, "politie_dacia_logan").toString()));

    public static final RegistryObject<EntityType<PolitieBmwSeria5Entity>> POLITIEBMWSERIA5 =
        ENTITY_TYPES.register("politie_bmw_seria5",
            () -> EntityType.Builder.<PolitieBmwSeria5Entity>of(PolitieBmwSeria5Entity::new, EntityClassification.MISC)
                .sized(2.0f, 1.0f)
                .build(new ResourceLocation(IlusionCarsMod.MOD_ID, "politie_bmw_seria5").toString()));

    public static final RegistryObject<EntityType<PolitieVwPassatEntity>> POLITIEVWPASSAT =
        ENTITY_TYPES.register("politie_vw_passat",
            () -> EntityType.Builder.<PolitieVwPassatEntity>of(PolitieVwPassatEntity::new, EntityClassification.MISC)
                .sized(2.0f, 1.0f)
                .build(new ResourceLocation(IlusionCarsMod.MOD_ID, "politie_vw_passat").toString()));

    public static final RegistryObject<EntityType<SmurdAmbulantaEntity>> SMURDAMBULANTA =
        ENTITY_TYPES.register("smurd_ambulanta",
            () -> EntityType.Builder.<SmurdAmbulantaEntity>of(SmurdAmbulantaEntity::new, EntityClassification.MISC)
                .sized(2.0f, 1.0f)
                .build(new ResourceLocation(IlusionCarsMod.MOD_ID, "smurd_ambulanta").toString()));

    public static final RegistryObject<EntityType<DiicotDusterEntity>> DIICOTDUSTER =
        ENTITY_TYPES.register("diicot_duster",
            () -> EntityType.Builder.<DiicotDusterEntity>of(DiicotDusterEntity::new, EntityClassification.MISC)
                .sized(2.0f, 1.0f)
                .build(new ResourceLocation(IlusionCarsMod.MOD_ID, "diicot_duster").toString()));

    public static final RegistryObject<EntityType<DiicotLoganMcvEntity>> DIICOTLOGANMCV =
        ENTITY_TYPES.register("diicot_logan_mcv",
            () -> EntityType.Builder.<DiicotLoganMcvEntity>of(DiicotLoganMcvEntity::new, EntityClassification.MISC)
                .sized(2.0f, 1.0f)
                .build(new ResourceLocation(IlusionCarsMod.MOD_ID, "diicot_logan_mcv").toString()));

    public static final RegistryObject<EntityType<BugattiChironEntity>> BUGATTICHIRON =
        ENTITY_TYPES.register("bugatti_chiron",
            () -> EntityType.Builder.<BugattiChironEntity>of(BugattiChironEntity::new, EntityClassification.MISC)
                .sized(2.0f, 1.0f)
                .build(new ResourceLocation(IlusionCarsMod.MOD_ID, "bugatti_chiron").toString()));

    public static final RegistryObject<EntityType<LamborghiniHuracanEntity>> LAMBORGHINIHURACAN =
        ENTITY_TYPES.register("lamborghini_huracan",
            () -> EntityType.Builder.<LamborghiniHuracanEntity>of(LamborghiniHuracanEntity::new, EntityClassification.MISC)
                .sized(2.0f, 1.0f)
                .build(new ResourceLocation(IlusionCarsMod.MOD_ID, "lamborghini_huracan").toString()));

    public static final RegistryObject<EntityType<FerrariSf90Entity>> FERRARISF90 =
        ENTITY_TYPES.register("ferrari_sf90",
            () -> EntityType.Builder.<FerrariSf90Entity>of(FerrariSf90Entity::new, EntityClassification.MISC)
                .sized(2.0f, 1.0f)
                .build(new ResourceLocation(IlusionCarsMod.MOD_ID, "ferrari_sf90").toString()));

    public static final RegistryObject<EntityType<McLaren720sEntity>> MCLAREN720S =
        ENTITY_TYPES.register("mc_laren720s",
            () -> EntityType.Builder.<McLaren720sEntity>of(McLaren720sEntity::new, EntityClassification.MISC)
                .sized(2.0f, 1.0f)
                .build(new ResourceLocation(IlusionCarsMod.MOD_ID, "mc_laren720s").toString()));

    public static final RegistryObject<EntityType<Porsche911Gt3Entity>> PORSCHE911GT3 =
        ENTITY_TYPES.register("porsche911_gt3",
            () -> EntityType.Builder.<Porsche911Gt3Entity>of(Porsche911Gt3Entity::new, EntityClassification.MISC)
                .sized(2.0f, 1.0f)
                .build(new ResourceLocation(IlusionCarsMod.MOD_ID, "porsche911_gt3").toString()));

    public static final RegistryObject<EntityType<MercedesAmgG63Entity>> MERCEDESAMGG63 =
        ENTITY_TYPES.register("mercedes_amg_g63",
            () -> EntityType.Builder.<MercedesAmgG63Entity>of(MercedesAmgG63Entity::new, EntityClassification.MISC)
                .sized(2.0f, 1.0f)
                .build(new ResourceLocation(IlusionCarsMod.MOD_ID, "mercedes_amg_g63").toString()));

    public static final RegistryObject<EntityType<RangeRoverSvrEntity>> RANGEROVERSVR =
        ENTITY_TYPES.register("range_rover_svr",
            () -> EntityType.Builder.<RangeRoverSvrEntity>of(RangeRoverSvrEntity::new, EntityClassification.MISC)
                .sized(2.0f, 1.0f)
                .build(new ResourceLocation(IlusionCarsMod.MOD_ID, "range_rover_svr").toString()));

    public static final RegistryObject<EntityType<BmwM5CompetitionEntity>> BMWM5COMPETITION =
        ENTITY_TYPES.register("bmw_m5_competition",
            () -> EntityType.Builder.<BmwM5CompetitionEntity>of(BmwM5CompetitionEntity::new, EntityClassification.MISC)
                .sized(2.0f, 1.0f)
                .build(new ResourceLocation(IlusionCarsMod.MOD_ID, "bmw_m5_competition").toString()));

    public static final RegistryObject<EntityType<AudiRs6AvantEntity>> AUDIRS6AVANT =
        ENTITY_TYPES.register("audi_rs6_avant",
            () -> EntityType.Builder.<AudiRs6AvantEntity>of(AudiRs6AvantEntity::new, EntityClassification.MISC)
                .sized(2.0f, 1.0f)
                .build(new ResourceLocation(IlusionCarsMod.MOD_ID, "audi_rs6_avant").toString()));

    public static final RegistryObject<EntityType<MercedesCls63Entity>> MERCEDESCLS63 =
        ENTITY_TYPES.register("mercedes_cls63",
            () -> EntityType.Builder.<MercedesCls63Entity>of(MercedesCls63Entity::new, EntityClassification.MISC)
                .sized(2.0f, 1.0f)
                .build(new ResourceLocation(IlusionCarsMod.MOD_ID, "mercedes_cls63").toString()));

    public static final RegistryObject<EntityType<AstonMartinDb11Entity>> ASTONMARTINDB11 =
        ENTITY_TYPES.register("aston_martin_db11",
            () -> EntityType.Builder.<AstonMartinDb11Entity>of(AstonMartinDb11Entity::new, EntityClassification.MISC)
                .sized(2.0f, 1.0f)
                .build(new ResourceLocation(IlusionCarsMod.MOD_ID, "aston_martin_db11").toString()));

    public static final RegistryObject<EntityType<BentleyContinentalEntity>> BENTLEYCONTINENTAL =
        ENTITY_TYPES.register("bentley_continental",
            () -> EntityType.Builder.<BentleyContinentalEntity>of(BentleyContinentalEntity::new, EntityClassification.MISC)
                .sized(2.0f, 1.0f)
                .build(new ResourceLocation(IlusionCarsMod.MOD_ID, "bentley_continental").toString()));

    public static final RegistryObject<EntityType<RollsRoyceGhostEntity>> ROLLSROYCEGHOST =
        ENTITY_TYPES.register("rolls_royce_ghost",
            () -> EntityType.Builder.<RollsRoyceGhostEntity>of(RollsRoyceGhostEntity::new, EntityClassification.MISC)
                .sized(2.0f, 1.0f)
                .build(new ResourceLocation(IlusionCarsMod.MOD_ID, "rolls_royce_ghost").toString()));

    public static final RegistryObject<EntityType<CadillacEscaladeEntity>> CADILLACESCALADE =
        ENTITY_TYPES.register("cadillac_escalade",
            () -> EntityType.Builder.<CadillacEscaladeEntity>of(CadillacEscaladeEntity::new, EntityClassification.MISC)
                .sized(2.0f, 1.0f)
                .build(new ResourceLocation(IlusionCarsMod.MOD_ID, "cadillac_escalade").toString()));

    public static final RegistryObject<EntityType<DodgeChallengerRtEntity>> DODGECHALLENGERRT =
        ENTITY_TYPES.register("dodge_challenger_rt",
            () -> EntityType.Builder.<DodgeChallengerRtEntity>of(DodgeChallengerRtEntity::new, EntityClassification.MISC)
                .sized(2.0f, 1.0f)
                .build(new ResourceLocation(IlusionCarsMod.MOD_ID, "dodge_challenger_rt").toString()));

    public static final RegistryObject<EntityType<FordMustangGt500Entity>> FORDMUSTANGGT500 =
        ENTITY_TYPES.register("ford_mustang_gt500",
            () -> EntityType.Builder.<FordMustangGt500Entity>of(FordMustangGt500Entity::new, EntityClassification.MISC)
                .sized(2.0f, 1.0f)
                .build(new ResourceLocation(IlusionCarsMod.MOD_ID, "ford_mustang_gt500").toString()));

    public static final RegistryObject<EntityType<ChevroletCorvetteEntity>> CHEVROLETCORVETTE =
        ENTITY_TYPES.register("chevrolet_corvette",
            () -> EntityType.Builder.<ChevroletCorvetteEntity>of(ChevroletCorvetteEntity::new, EntityClassification.MISC)
                .sized(2.0f, 1.0f)
                .build(new ResourceLocation(IlusionCarsMod.MOD_ID, "chevrolet_corvette").toString()));

    public static final RegistryObject<EntityType<BmwM8GranCoupeEntity>> BMWM8GRANCOUPE =
        ENTITY_TYPES.register("bmw_m8_gran_coupe",
            () -> EntityType.Builder.<BmwM8GranCoupeEntity>of(BmwM8GranCoupeEntity::new, EntityClassification.MISC)
                .sized(2.0f, 1.0f)
                .build(new ResourceLocation(IlusionCarsMod.MOD_ID, "bmw_m8_gran_coupe").toString()));

    public static final RegistryObject<EntityType<PorscheCayenneGtsEntity>> PORSCHECAYENNEGTS =
        ENTITY_TYPES.register("porsche_cayenne_gts",
            () -> EntityType.Builder.<PorscheCayenneGtsEntity>of(PorscheCayenneGtsEntity::new, EntityClassification.MISC)
                .sized(2.0f, 1.0f)
                .build(new ResourceLocation(IlusionCarsMod.MOD_ID, "porsche_cayenne_gts").toString()));

    public static final RegistryObject<EntityType<TeslaModelSPlaidEntity>> TESLAMODELSPLAID =
        ENTITY_TYPES.register("tesla_model_s_plaid",
            () -> EntityType.Builder.<TeslaModelSPlaidEntity>of(TeslaModelSPlaidEntity::new, EntityClassification.MISC)
                .sized(2.0f, 1.0f)
                .build(new ResourceLocation(IlusionCarsMod.MOD_ID, "tesla_model_s_plaid").toString()));

    public static final RegistryObject<EntityType<AudiR8V10Entity>> AUDIR8V10 =
        ENTITY_TYPES.register("audi_r8_v10",
            () -> EntityType.Builder.<AudiR8V10Entity>of(AudiR8V10Entity::new, EntityClassification.MISC)
                .sized(2.0f, 1.0f)
                .build(new ResourceLocation(IlusionCarsMod.MOD_ID, "audi_r8_v10").toString()));

    public static final RegistryObject<EntityType<MercedesMaybachSEntity>> MERCEDESMAYBACHS =
        ENTITY_TYPES.register("mercedes_maybach_s",
            () -> EntityType.Builder.<MercedesMaybachSEntity>of(MercedesMaybachSEntity::new, EntityClassification.MISC)
                .sized(2.0f, 1.0f)
                .build(new ResourceLocation(IlusionCarsMod.MOD_ID, "mercedes_maybach_s").toString()));

    public static final RegistryObject<EntityType<BmwX5mEntity>> BMWX5M =
        ENTITY_TYPES.register("bmw_x5m",
            () -> EntityType.Builder.<BmwX5mEntity>of(BmwX5mEntity::new, EntityClassification.MISC)
                .sized(2.0f, 1.0f)
                .build(new ResourceLocation(IlusionCarsMod.MOD_ID, "bmw_x5m").toString()));

    public static final RegistryObject<EntityType<MaseratiGhibliEntity>> MASERATIGHIBLI =
        ENTITY_TYPES.register("maserati_ghibli",
            () -> EntityType.Builder.<MaseratiGhibliEntity>of(MaseratiGhibliEntity::new, EntityClassification.MISC)
                .sized(2.0f, 1.0f)
                .build(new ResourceLocation(IlusionCarsMod.MOD_ID, "maserati_ghibli").toString()));

    public static final RegistryObject<EntityType<VolkswagenGolfREntity>> VOLKSWAGENGOLFR =
        ENTITY_TYPES.register("volkswagen_golf_r",
            () -> EntityType.Builder.<VolkswagenGolfREntity>of(VolkswagenGolfREntity::new, EntityClassification.MISC)
                .sized(2.0f, 1.0f)
                .build(new ResourceLocation(IlusionCarsMod.MOD_ID, "volkswagen_golf_r").toString()));

    public static final RegistryObject<EntityType<HondaCivicTypeREntity>> HONDACIVICTYPER =
        ENTITY_TYPES.register("honda_civic_type_r",
            () -> EntityType.Builder.<HondaCivicTypeREntity>of(HondaCivicTypeREntity::new, EntityClassification.MISC)
                .sized(2.0f, 1.0f)
                .build(new ResourceLocation(IlusionCarsMod.MOD_ID, "honda_civic_type_r").toString()));

    public static final RegistryObject<EntityType<NissanGtrR35Entity>> NISSANGTRR35 =
        ENTITY_TYPES.register("nissan_gtr_r35",
            () -> EntityType.Builder.<NissanGtrR35Entity>of(NissanGtrR35Entity::new, EntityClassification.MISC)
                .sized(2.0f, 1.0f)
                .build(new ResourceLocation(IlusionCarsMod.MOD_ID, "nissan_gtr_r35").toString()));

    public static final RegistryObject<EntityType<SubaruImprezaWrxEntity>> SUBARUIMPREZAWRX =
        ENTITY_TYPES.register("subaru_impreza_wrx",
            () -> EntityType.Builder.<SubaruImprezaWrxEntity>of(SubaruImprezaWrxEntity::new, EntityClassification.MISC)
                .sized(2.0f, 1.0f)
                .build(new ResourceLocation(IlusionCarsMod.MOD_ID, "subaru_impreza_wrx").toString()));

    public static final RegistryObject<EntityType<ToyotaSupraMk5Entity>> TOYOTASUPRAMK5 =
        ENTITY_TYPES.register("toyota_supra_mk5",
            () -> EntityType.Builder.<ToyotaSupraMk5Entity>of(ToyotaSupraMk5Entity::new, EntityClassification.MISC)
                .sized(2.0f, 1.0f)
                .build(new ResourceLocation(IlusionCarsMod.MOD_ID, "toyota_supra_mk5").toString()));

}
