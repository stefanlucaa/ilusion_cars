package com.ilusion.cars.renderer;

import com.ilusion.cars.entity.ToyotaSupraMk5Entity;
import com.ilusion.cars.model.ToyotaSupraMk5Model;
import net.minecraft.client.renderer.entity.EntityRendererManager;

public class ToyotaSupraMk5Renderer extends BaseCarRenderer<ToyotaSupraMk5Entity> {
    public ToyotaSupraMk5Renderer(EntityRendererManager manager) {
        super(manager, new ToyotaSupraMk5Model(), "toyota_supra_mk5");
    }
}
