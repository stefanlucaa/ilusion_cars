package com.ilusion.cars.entity;

import com.ilusion.cars.init.EntityInit;
import net.minecraft.entity.EntityType;
import net.minecraft.world.World;

/** Nissan GT-R R35 */
public class NissanGtrR35Entity extends BaseCarEntity {

    public NissanGtrR35Entity(EntityType<? extends BaseCarEntity> type, World world) {
        super(type, world);
        this.maxSpeed  = 1.05f;
        this.accel     = 0.072f;
        this.turnSpeed = 5.2f;
        this.hasSiren  = false;
    }
}
