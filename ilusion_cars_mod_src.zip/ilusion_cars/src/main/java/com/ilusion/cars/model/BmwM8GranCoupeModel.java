package com.ilusion.cars.model;

import com.ilusion.cars.entity.BmwM8GranCoupeEntity;

public class BmwM8GranCoupeModel extends BaseCarModel<BmwM8GranCoupeEntity> {

    @Override
    protected void buildParts() {
        setupParts(
            25,   // body half-length
            11,   // body half-width
            3,   // body bottom y
            6,   // body top y
            10,   // cabin top y
            true,
            false
        );
    }
}
