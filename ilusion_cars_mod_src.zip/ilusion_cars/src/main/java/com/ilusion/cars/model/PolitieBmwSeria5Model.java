package com.ilusion.cars.model;

import com.ilusion.cars.entity.PolitieBmwSeria5Entity;

public class PolitieBmwSeria5Model extends BaseCarModel<PolitieBmwSeria5Entity> {

    @Override
    protected void buildParts() {
        setupParts(
            24,   // body half-length
            11,   // body half-width
            3,   // body bottom y
            6,   // body top y
            11,   // cabin top y
            false,
            true
        );
    }
}
