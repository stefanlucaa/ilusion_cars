package com.ilusion.cars.renderer;

import com.ilusion.cars.entity.RangeRoverSvrEntity;
import com.ilusion.cars.model.RangeRoverSvrModel;
import net.minecraft.client.renderer.entity.EntityRendererManager;

public class RangeRoverSvrRenderer extends BaseCarRenderer<RangeRoverSvrEntity> {
    public RangeRoverSvrRenderer(EntityRendererManager manager) {
        super(manager, new RangeRoverSvrModel(), "range_rover_svr");
    }
}
