package com.ilusion.cars.entity;

import com.ilusion.cars.init.EntityInit;
import net.minecraft.entity.EntityType;
import net.minecraft.world.World;

/** Mercedes Maybach S */
public class MercedesMaybachSEntity extends BaseCarEntity {

    public MercedesMaybachSEntity(EntityType<? extends BaseCarEntity> type, World world) {
        super(type, world);
        this.maxSpeed  = 0.90f;
        this.accel     = 0.060f;
        this.turnSpeed = 4.5f;
        this.hasSiren  = false;
    }
}
