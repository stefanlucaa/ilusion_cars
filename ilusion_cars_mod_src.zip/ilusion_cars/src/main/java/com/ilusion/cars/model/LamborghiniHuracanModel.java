package com.ilusion.cars.model;

import com.ilusion.cars.entity.LamborghiniHuracanEntity;

public class LamborghiniHuracanModel extends BaseCarModel<LamborghiniHuracanEntity> {

    @Override
    protected void buildParts() {
        setupParts(
            26,   // body half-length
            11,   // body half-width
            2,   // body bottom y
            5,   // body top y
            9,   // cabin top y
            true,
            false
        );
    }
}
