package com.ilusion.cars.renderer;

import com.ilusion.cars.entity.BugattiChironEntity;
import com.ilusion.cars.model.BugattiChironModel;
import net.minecraft.client.renderer.entity.EntityRendererManager;

public class BugattiChironRenderer extends BaseCarRenderer<BugattiChironEntity> {
    public BugattiChironRenderer(EntityRendererManager manager) {
        super(manager, new BugattiChironModel(), "bugatti_chiron");
    }
}
