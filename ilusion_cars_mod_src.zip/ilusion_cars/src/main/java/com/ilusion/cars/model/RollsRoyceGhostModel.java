package com.ilusion.cars.model;

import com.ilusion.cars.entity.RollsRoyceGhostEntity;

public class RollsRoyceGhostModel extends BaseCarModel<RollsRoyceGhostEntity> {

    @Override
    protected void buildParts() {
        setupParts(
            26,   // body half-length
            13,   // body half-width
            3,   // body bottom y
            7,   // body top y
            11,   // cabin top y
            false,
            false
        );
    }
}
