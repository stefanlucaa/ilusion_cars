package com.ilusion.cars.renderer;

import com.ilusion.cars.entity.AudiR8V10Entity;
import com.ilusion.cars.model.AudiR8V10Model;
import net.minecraft.client.renderer.entity.EntityRendererManager;

public class AudiR8V10Renderer extends BaseCarRenderer<AudiR8V10Entity> {
    public AudiR8V10Renderer(EntityRendererManager manager) {
        super(manager, new AudiR8V10Model(), "audi_r8_v10");
    }
}
