package com.ilusion.cars.entity;

import com.ilusion.cars.init.EntityInit;
import net.minecraft.entity.EntityType;
import net.minecraft.world.World;

/** Politie Dacia Logan */
public class PolitieDaciaLoganEntity extends BaseCarEntity {

    public PolitieDaciaLoganEntity(EntityType<? extends BaseCarEntity> type, World world) {
        super(type, world);
        this.maxSpeed  = 0.55f;
        this.accel     = 0.035f;
        this.turnSpeed = 4.0f;
        this.hasSiren  = true;
    }
}
