package com.ilusion.cars.entity;

import com.ilusion.cars.init.EntityInit;
import net.minecraft.entity.EntityType;
import net.minecraft.world.World;

/** Chevrolet Corvette */
public class ChevroletCorvetteEntity extends BaseCarEntity {

    public ChevroletCorvetteEntity(EntityType<? extends BaseCarEntity> type, World world) {
        super(type, world);
        this.maxSpeed  = 1.05f;
        this.accel     = 0.075f;
        this.turnSpeed = 5.2f;
        this.hasSiren  = false;
    }
}
