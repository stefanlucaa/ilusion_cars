package com.ilusion.cars.model;

import com.ilusion.cars.entity.SmurdAmbulantaEntity;

public class SmurdAmbulantaModel extends BaseCarModel<SmurdAmbulantaEntity> {

    @Override
    protected void buildParts() {
        setupParts(
            26,   // body half-length
            12,   // body half-width
            3,   // body bottom y
            9,   // body top y
            11,   // cabin top y
            false,
            true
        );
    }
}
