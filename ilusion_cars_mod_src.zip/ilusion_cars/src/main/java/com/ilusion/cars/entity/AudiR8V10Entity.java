package com.ilusion.cars.entity;

import com.ilusion.cars.init.EntityInit;
import net.minecraft.entity.EntityType;
import net.minecraft.world.World;

/** Audi R8 V10 */
public class AudiR8V10Entity extends BaseCarEntity {

    public AudiR8V10Entity(EntityType<? extends BaseCarEntity> type, World world) {
        super(type, world);
        this.maxSpeed  = 1.10f;
        this.accel     = 0.075f;
        this.turnSpeed = 5.5f;
        this.hasSiren  = false;
    }
}
