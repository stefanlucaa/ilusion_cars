package com.ilusion.cars.model;

import com.ilusion.cars.entity.ChevroletCorvetteEntity;

public class ChevroletCorvetteModel extends BaseCarModel<ChevroletCorvetteEntity> {

    @Override
    protected void buildParts() {
        setupParts(
            25,   // body half-length
            11,   // body half-width
            2,   // body bottom y
            5,   // body top y
            9,   // cabin top y
            true,
            false
        );
    }
}
