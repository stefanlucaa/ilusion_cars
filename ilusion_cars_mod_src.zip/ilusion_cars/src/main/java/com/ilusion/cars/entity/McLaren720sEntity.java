package com.ilusion.cars.entity;

import com.ilusion.cars.init.EntityInit;
import net.minecraft.entity.EntityType;
import net.minecraft.world.World;

/** McLaren 720S */
public class McLaren720sEntity extends BaseCarEntity {

    public McLaren720sEntity(EntityType<? extends BaseCarEntity> type, World world) {
        super(type, world);
        this.maxSpeed  = 1.10f;
        this.accel     = 0.075f;
        this.turnSpeed = 5.5f;
        this.hasSiren  = false;
    }
}
