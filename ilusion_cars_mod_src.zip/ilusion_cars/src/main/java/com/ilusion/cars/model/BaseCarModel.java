package com.ilusion.cars.model;

import com.mojang.blaze3d.matrix.MatrixStack;
import com.mojang.blaze3d.vertex.IVertexBuilder;
import net.minecraft.client.renderer.entity.model.EntityModel;
import net.minecraft.client.renderer.model.ModelRenderer;
import com.ilusion.cars.entity.BaseCarEntity;

/**
 * Base model class for all Ilusion car entities.
 * Each car subclass overrides buildParts() with its own dimensions.
 */
public abstract class BaseCarModel<T extends BaseCarEntity> extends EntityModel<T> {

    protected ModelRenderer body;
    protected ModelRenderer hood;
    protected ModelRenderer cabin;
    protected ModelRenderer trunk;
    protected ModelRenderer wheelFL;
    protected ModelRenderer wheelFR;
    protected ModelRenderer wheelRL;
    protected ModelRenderer wheelRR;
    protected ModelRenderer headlightL;
    protected ModelRenderer headlightR;
    protected ModelRenderer taillightL;
    protected ModelRenderer taillightR;
    // Optional extras
    protected ModelRenderer spoiler;
    protected ModelRenderer lightbar;

    public BaseCarModel() {
        texWidth  = 64;
        texHeight = 64;
        buildParts();
    }

    /** Override in subclass to call setupParts() with custom dimensions. */
    protected abstract void buildParts();

    /**
     * Sets up all model parts given body/cabin/wheel parameters.
     *
     * @param bl   body half-length (x)
     * @param bw   body half-width  (z)
     * @param by   body bottom y (Minecraft model space, y=0 is ground)
     * @param bt   body top y
     * @param cy   cabin top y
     * @param hasSpoiler  whether to add rear spoiler part
     * @param hasLightbar whether to add roof lightbar
     */
    protected void setupParts(int bl, int bw, int by, int bt, int cy,
                               boolean hasSpoiler, boolean hasLightbar) {
        // Body
        body = new ModelRenderer(this);
        body.setPos(0, 24 - bt, 0);
        body.texOffs(0, 0).addBox(-bl, 0, -bw, bl*2, bt-by, bw*2);

        // Hood
        hood = new ModelRenderer(this);
        hood.setPos(0, 24 - bt, 0);
        hood.texOffs(16, 0).addBox(bl/3, 0, -(bw-2), bl - bl/3, 2, (bw-2)*2);

        // Cabin
        cabin = new ModelRenderer(this);
        cabin.setPos(0, 24 - bt, 0);
        cabin.texOffs(24, 0).addBox(-bl+6, 0, -(bw-2), bl*2-14, cy-bt, (bw-2)*2);

        // Trunk
        trunk = new ModelRenderer(this);
        trunk.setPos(0, 24 - bt, 0);
        trunk.texOffs(32, 0).addBox(-bl, 0, -(bw-2), 6, 3, (bw-2)*2);

        // Wheels
        int wy = 24 - by + 3;
        wheelFL = new ModelRenderer(this);
        wheelFL.setPos(0, 0, 0);
        wheelFL.texOffs(40, 0).addBox(bl-5, wy-5, bw-1, 3, 5, 3);

        wheelFR = new ModelRenderer(this);
        wheelFR.setPos(0, 0, 0);
        wheelFR.texOffs(40, 0).addBox(bl-5, wy-5, -bw-2, 3, 5, 3);

        wheelRL = new ModelRenderer(this);
        wheelRL.setPos(0, 0, 0);
        wheelRL.texOffs(40, 0).addBox(-bl+2, wy-5, bw-1, 3, 5, 3);

        wheelRR = new ModelRenderer(this);
        wheelRR.setPos(0, 0, 0);
        wheelRR.texOffs(40, 0).addBox(-bl+2, wy-5, -bw-2, 3, 5, 3);

        // Headlights
        headlightL = new ModelRenderer(this);
        headlightL.setPos(0, 0, 0);
        headlightL.texOffs(48, 0).addBox(bl-1, 24-bt+1, bw-2, 2, 2, 2);

        headlightR = new ModelRenderer(this);
        headlightR.setPos(0, 0, 0);
        headlightR.texOffs(48, 0).addBox(bl-1, 24-bt+1, -bw, 2, 2, 2);

        // Taillights
        taillightL = new ModelRenderer(this);
        taillightL.setPos(0, 0, 0);
        taillightL.texOffs(50, 0).addBox(-bl-1, 24-bt+1, bw-2, 2, 2, 2);

        taillightR = new ModelRenderer(this);
        taillightR.setPos(0, 0, 0);
        taillightR.texOffs(50, 0).addBox(-bl-1, 24-bt+1, -bw, 2, 2, 2);

        if (hasSpoiler) {
            spoiler = new ModelRenderer(this);
            spoiler.setPos(0, 0, 0);
            spoiler.texOffs(52, 0).addBox(-bl-2, 24-cy, -(bw-2), 2, 3, (bw-2)*2);
        }

        if (hasLightbar) {
            lightbar = new ModelRenderer(this);
            lightbar.setPos(0, 0, 0);
            lightbar.texOffs(56, 0).addBox(-bl+8, 24-cy, -(bw-2), bl*2-16, 2, (bw-2)*2);
        }
    }

    @Override
    public void setupAnim(T entity, float limbSwing, float limbSwingAmount,
                          float ageInTicks, float netHeadYaw, float headPitch) {
        // No animation needed for cars (static model, entity rotation handles movement)
    }

    @Override
    public void renderToBuffer(MatrixStack ms, IVertexBuilder vb,
                               int packedLight, int packedOverlay,
                               float r, float g, float b, float a) {
        body.render(ms, vb, packedLight, packedOverlay, r, g, b, a);
        hood.render(ms, vb, packedLight, packedOverlay, r, g, b, a);
        cabin.render(ms, vb, packedLight, packedOverlay, r, g, b, a);
        trunk.render(ms, vb, packedLight, packedOverlay, r, g, b, a);
        wheelFL.render(ms, vb, packedLight, packedOverlay, r, g, b, a);
        wheelFR.render(ms, vb, packedLight, packedOverlay, r, g, b, a);
        wheelRL.render(ms, vb, packedLight, packedOverlay, r, g, b, a);
        wheelRR.render(ms, vb, packedLight, packedOverlay, r, g, b, a);
        headlightL.render(ms, vb, packedLight, packedOverlay, r, g, b, a);
        headlightR.render(ms, vb, packedLight, packedOverlay, r, g, b, a);
        taillightL.render(ms, vb, packedLight, packedOverlay, r, g, b, a);
        taillightR.render(ms, vb, packedLight, packedOverlay, r, g, b, a);
        if (spoiler  != null) spoiler.render(ms, vb, packedLight, packedOverlay, r, g, b, a);
        if (lightbar != null) lightbar.render(ms, vb, packedLight, packedOverlay, r, g, b, a);
    }
}
