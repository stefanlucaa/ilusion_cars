package com.ilusion.cars.model;

import com.ilusion.cars.entity.BmwM5CompetitionEntity;

public class BmwM5CompetitionModel extends BaseCarModel<BmwM5CompetitionEntity> {

    @Override
    protected void buildParts() {
        setupParts(
            24,   // body half-length
            11,   // body half-width
            3,   // body bottom y
            6,   // body top y
            10,   // cabin top y
            true,
            false
        );
    }
}
