package com.ilusion.cars.renderer;

import com.ilusion.cars.entity.ChevroletCorvetteEntity;
import com.ilusion.cars.model.ChevroletCorvetteModel;
import net.minecraft.client.renderer.entity.EntityRendererManager;

public class ChevroletCorvetteRenderer extends BaseCarRenderer<ChevroletCorvetteEntity> {
    public ChevroletCorvetteRenderer(EntityRendererManager manager) {
        super(manager, new ChevroletCorvetteModel(), "chevrolet_corvette");
    }
}
