package com.ilusion.cars.entity;

import com.ilusion.cars.init.EntityInit;
import net.minecraft.entity.EntityType;
import net.minecraft.world.World;

/** Dodge Challenger R/T */
public class DodgeChallengerRtEntity extends BaseCarEntity {

    public DodgeChallengerRtEntity(EntityType<? extends BaseCarEntity> type, World world) {
        super(type, world);
        this.maxSpeed  = 0.95f;
        this.accel     = 0.065f;
        this.turnSpeed = 4.5f;
        this.hasSiren  = false;
    }
}
