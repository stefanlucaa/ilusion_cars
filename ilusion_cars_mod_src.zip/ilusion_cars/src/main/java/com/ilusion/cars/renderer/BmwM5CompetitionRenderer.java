package com.ilusion.cars.renderer;

import com.ilusion.cars.entity.BmwM5CompetitionEntity;
import com.ilusion.cars.model.BmwM5CompetitionModel;
import net.minecraft.client.renderer.entity.EntityRendererManager;

public class BmwM5CompetitionRenderer extends BaseCarRenderer<BmwM5CompetitionEntity> {
    public BmwM5CompetitionRenderer(EntityRendererManager manager) {
        super(manager, new BmwM5CompetitionModel(), "bmw_m5_competition");
    }
}
