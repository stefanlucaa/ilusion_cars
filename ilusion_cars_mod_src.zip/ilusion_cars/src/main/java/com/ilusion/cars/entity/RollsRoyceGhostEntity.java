package com.ilusion.cars.entity;

import com.ilusion.cars.init.EntityInit;
import net.minecraft.entity.EntityType;
import net.minecraft.world.World;

/** Rolls-Royce Ghost */
public class RollsRoyceGhostEntity extends BaseCarEntity {

    public RollsRoyceGhostEntity(EntityType<? extends BaseCarEntity> type, World world) {
        super(type, world);
        this.maxSpeed  = 0.85f;
        this.accel     = 0.055f;
        this.turnSpeed = 4.2f;
        this.hasSiren  = false;
    }
}
