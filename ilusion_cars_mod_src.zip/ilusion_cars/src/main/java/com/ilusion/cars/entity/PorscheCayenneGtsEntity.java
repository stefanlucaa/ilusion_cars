package com.ilusion.cars.entity;

import com.ilusion.cars.init.EntityInit;
import net.minecraft.entity.EntityType;
import net.minecraft.world.World;

/** Porsche Cayenne GTS */
public class PorscheCayenneGtsEntity extends BaseCarEntity {

    public PorscheCayenneGtsEntity(EntityType<? extends BaseCarEntity> type, World world) {
        super(type, world);
        this.maxSpeed  = 0.85f;
        this.accel     = 0.058f;
        this.turnSpeed = 4.5f;
        this.hasSiren  = false;
    }
}
