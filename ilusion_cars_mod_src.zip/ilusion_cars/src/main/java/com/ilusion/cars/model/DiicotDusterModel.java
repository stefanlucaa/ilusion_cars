package com.ilusion.cars.model;

import com.ilusion.cars.entity.DiicotDusterEntity;

public class DiicotDusterModel extends BaseCarModel<DiicotDusterEntity> {

    @Override
    protected void buildParts() {
        setupParts(
            23,   // body half-length
            12,   // body half-width
            3,   // body bottom y
            7,   // body top y
            11,   // cabin top y
            false,
            true
        );
    }
}
