package com.ilusion.cars.renderer;

import com.ilusion.cars.entity.Porsche911Gt3Entity;
import com.ilusion.cars.model.Porsche911Gt3Model;
import net.minecraft.client.renderer.entity.EntityRendererManager;

public class Porsche911Gt3Renderer extends BaseCarRenderer<Porsche911Gt3Entity> {
    public Porsche911Gt3Renderer(EntityRendererManager manager) {
        super(manager, new Porsche911Gt3Model(), "porsche911_gt3");
    }
}
