package com.ilusion.cars.entity;

import com.ilusion.cars.init.EntityInit;
import net.minecraft.entity.EntityType;
import net.minecraft.world.World;

/** Politie BMW Seria 5 */
public class PolitieBmwSeria5Entity extends BaseCarEntity {

    public PolitieBmwSeria5Entity(EntityType<? extends BaseCarEntity> type, World world) {
        super(type, world);
        this.maxSpeed  = 0.70f;
        this.accel     = 0.045f;
        this.turnSpeed = 4.5f;
        this.hasSiren  = true;
    }
}
