package com.ilusion.cars.entity;

import com.ilusion.cars.init.EntityInit;
import net.minecraft.entity.EntityType;
import net.minecraft.world.World;

/** Cadillac Escalade */
public class CadillacEscaladeEntity extends BaseCarEntity {

    public CadillacEscaladeEntity(EntityType<? extends BaseCarEntity> type, World world) {
        super(type, world);
        this.maxSpeed  = 0.75f;
        this.accel     = 0.050f;
        this.turnSpeed = 3.8f;
        this.hasSiren  = false;
    }
}
