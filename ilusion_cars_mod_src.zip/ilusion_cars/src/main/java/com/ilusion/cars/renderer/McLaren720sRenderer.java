package com.ilusion.cars.renderer;

import com.ilusion.cars.entity.McLaren720sEntity;
import com.ilusion.cars.model.McLaren720sModel;
import net.minecraft.client.renderer.entity.EntityRendererManager;

public class McLaren720sRenderer extends BaseCarRenderer<McLaren720sEntity> {
    public McLaren720sRenderer(EntityRendererManager manager) {
        super(manager, new McLaren720sModel(), "mc_laren720s");
    }
}
