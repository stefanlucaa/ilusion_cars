# 🚗 Ilusion Cars Pack — Minecraft 1.16.5 Forge Mod

**35 masini custom** cu comenzi `/summon ils.<NumeMasina>`

---

## 📦 Instalare

### Cerinte:
- Minecraft **1.16.5**
- Forge **36.2.39** (sau mai nou din 36.x)
- Java 8

### Compilare:
```bash
# 1. Cloneaza / dezarhiveaza folderul ilusion_cars
cd ilusion_cars

# 2. Descarca Forge MDK de la https://files.minecraftforge.net/
#    (Minecraft 1.16.5, versiunea recomandata)
#    Copiaza gradlew, gradle/, settings.gradle din MDK in acest folder

# 3. Ruleaza setup
./gradlew genEclipseRuns   # sau genIntellijRuns

# 4. Compileaza .jar
./gradlew build

# 5. .jar-ul apare in build/libs/ilusioncar-1.0.0.jar
#    Pune-l in folderul mods/ din Minecraft
```

---

## 🎮 Comenzi In-Game

```
/summon ils.<NumeMasina>
```

### 🚔 Politie
```
/summon ils.PolitieDaciaLogan
/summon ils.PolitieBmwSeria5
/summon ils.PolitieVwPassat
```

### 🚑 SMURD
```
/summon ils.SmurdAmbulanta
```

### 🔵 DIICOT
```
/summon ils.DiicotDuster
/summon ils.DiicotLoganMcv
```

### 🏎️ Masini de Lux
```
/summon ils.BugattiChiron
/summon ils.LamborghiniHuracan
/summon ils.FerrariSf90
/summon ils.McLaren720s
/summon ils.Porsche911Gt3
/summon ils.MercedesAmgG63
/summon ils.RangeRoverSvr
/summon ils.BmwM5Competition
/summon ils.AudiRs6Avant
/summon ils.MercedesCls63
/summon ils.AstonMartinDb11
/summon ils.BentleyContinental
/summon ils.RollsRoyceGhost
/summon ils.CadillacEscalade
/summon ils.DodgeChallengerRt
/summon ils.FordMustangGt500
/summon ils.ChevroletCorvette
/summon ils.BmwM8GranCoupe
/summon ils.PorscheCayenneGts
/summon ils.TeslaModelSPlaid
/summon ils.AudiR8V10
/summon ils.MercedesMaybachS
/summon ils.BmwX5m
/summon ils.MaseratiGhibli
/summon ils.VolkswagenGolfR
/summon ils.HondaCivicTypeR
/summon ils.NissanGtrR35
/summon ils.SubaruImprezaWrx
/summon ils.ToyotaSupraMk5
```

---

## 🕹️ Cum conduci:

- **Click dreapta** pe masina ca sa intri
- **W / S** — accelereaza / frana
- **A / D** — vireaza stanga / dreapta
- **Shift** — cobori din masina

---

## 📁 Structura proiectului

```
ilusion_cars/
├── build.gradle
├── src/main/java/com/ilusion/cars/
│   ├── IlusionCarsMod.java          ← Main class
│   ├── ClientSetup.java             ← Renderer registration
│   ├── entity/
│   │   ├── BaseCarEntity.java       ← Logica de condus
│   │   └── *Entity.java             ← 35 clase entitati
│   ├── model/
│   │   ├── BaseCarModel.java        ← Model 3D baza
│   │   └── *Model.java              ← 35 modele
│   ├── renderer/
│   │   ├── BaseCarRenderer.java     ← Renderer baza
│   │   └── *Renderer.java           ← 35 renderere
│   ├── init/
│   │   └── EntityInit.java          ← Inregistrare entitati
│   └── command/
│       └── SummonCarCommand.java    ← /summon ils.*
└── src/main/resources/
    ├── META-INF/mods.toml
    ├── pack.mcmeta
    └── assets/ilusioncar/
        ├── lang/en_us.json
        └── textures/entity/
            └── *.png                ← 35 texturi
```

---

## ⚡ Viteze masini

| Masina | Viteza max | Acceleratie |
|--------|-----------|-------------|
| Bugatti Chiron | ⚡⚡⚡⚡⚡ | ⚡⚡⚡⚡ |
| Tesla Model S Plaid | ⚡⚡⚡⚡⚡ | ⚡⚡⚡⚡⚡ |
| Lamborghini Huracan | ⚡⚡⚡⚡⚡ | ⚡⚡⚡⚡ |
| McLaren 720S | ⚡⚡⚡⚡⚡ | ⚡⚡⚡⚡ |
| Politie BMW Seria 5 | ⚡⚡⚡ | ⚡⚡⚡ |
| SMURD Ambulanta | ⚡⚡⚡ | ⚡⚡⚡ |
| Dacia Logan (Politie) | ⚡⚡ | ⚡⚡ |

---

Made with ❤️ for **HypeCity** | Ilusion Cars Pack v1.0.0
